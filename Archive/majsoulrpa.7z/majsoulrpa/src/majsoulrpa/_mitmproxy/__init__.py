from pathlib import Path
from typing import Final

_SNIFFER_PATH: Final = Path(__file__).parent / "sniffer.py"
