from ._config import get_config

__all__ = [
	"get_config",
]
