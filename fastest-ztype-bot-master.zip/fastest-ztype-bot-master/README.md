# The Fastest Ztype Bot
Currently holding the (unofficial) world record of the fastest Ztype Bot.

You do need pyautogui for this to work, this code (so far) has been optimized to get up to Wave 99 in Ztype passing the Js injecting code which you can find [here](https://github.com/in5ikt/z-bot) and [here](https://github.com/andrewboudreau/ztypeHack). To my rough calculations it types around 600-700 wpm, truly inhuman. I am trying to push to reach and pass wave 100, any optimization recomendations you can fork and make a pull request or flag as an issue.

# Instructions
1. Go to https://zty.pe/
2. Open Ztype Bot.py (preferably using cmd, so you can cancel it easier)
3. Click on New Game and Enjoy!





# Short explaination thing idk really...
This code works by typing the most common letters first and the least common last, hundreds of times in a second, in a single command, this dramatically reduces the time between letters. Will release a short video on the [YouTube Channel](https://www.youtube.com/channel/UCU85Z-39Q67jL2eUUgkooTQ)
